//
//  CollectionReusableView.swift
//  group_5_assignment4
//
//  Created by Yanbing Fang on 3/6/20.
//  Copyright © 2020 Jeffrey Cordes. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
        
}
