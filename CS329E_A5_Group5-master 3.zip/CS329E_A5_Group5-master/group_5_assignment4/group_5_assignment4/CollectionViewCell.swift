//
//  CollectionViewCell.swift
//  group_5_assignment4
//
//  Created by Yanbing Fang on 3/5/20.
//  Copyright © 2020 Jeffrey Cordes. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var animalImageView: UIImageView!
    @IBOutlet weak var animalLabel: UILabel!
}
